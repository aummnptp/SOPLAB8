package com.example.ordersservice;

public enum OrderStatus {
    CREATED, APPROVED, REJECTED
}
