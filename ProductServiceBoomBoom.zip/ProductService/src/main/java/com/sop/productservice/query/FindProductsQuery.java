package com.sop.productservice.query;

public class FindProductsQuery {
}
