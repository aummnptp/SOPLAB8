package com.sop.productservice.rest;

import org.springframework.boot.autoconfigure.couchbase.CouchbaseProperties;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductsController {
    private final Environment env;

    public ProductsController(Environment env){
        this.env=env;
    }

        @PostMapping
        public String createProduct(){
            return "HTTP POST Handler";
        }
        @GetMapping
        public String getProduct(){
            return"HTTP GET Handler"+ env.getProperty("local.server.port");
        }
        @PutMapping
        public String updateProduct(){
            return "HTTP PUT Handler";
        }
        @DeleteMapping
        public  String deleteProduct(){
            return "HTTP DELETE Handler";
        }



}
